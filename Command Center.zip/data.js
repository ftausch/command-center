// Command Center — Mock Data for both workspaces
// All content in German (content), UI labels in English

window.CC_DATA = {
  brands: {
    unicornbakery: {
      id: 'unicornbakery',
      name: 'UnicornBakery',
      sub: 'Podcast · B2B Startup Media',
      initials: 'UB',
      color: '#1a3d5c',
      tagline: 'Der Podcast für Founder, CEOs & das Startup-Ökosystem.',
    },
    selbstfrei: {
      id: 'selbstfrei',
      name: 'SelbstFrei',
      sub: 'Podcast · Wachstum & Reichweite',
      initials: 'SF',
      color: '#7a3dc4',
      tagline: 'Gründerstorys, die Reichweite verdienen.',
    },
  },

  users: [
    { id: 'fabian', name: 'Fabian Tausch', initials: 'FT', role: 'Owner', workspaces: ['unicornbakery', 'selbstfrei'], online: true },
    { id: 'tim', name: 'Tim Berger', initials: 'TB', role: 'Manager', workspaces: ['unicornbakery', 'selbstfrei'], online: true },
    { id: 'mara', name: 'Mara Linde', initials: 'ML', role: 'Cutter', workspaces: ['unicornbakery'], online: true },
    { id: 'jonas', name: 'Jonas Kraft', initials: 'JK', role: 'Cutter', workspaces: ['selbstfrei'], online: false },
    { id: 'lena', name: 'Lena Voss', initials: 'LV', role: 'Designer', workspaces: ['unicornbakery', 'selbstfrei'], online: true },
    { id: 'paul', name: 'Paul Reiser', initials: 'PR', role: 'Social Media', workspaces: ['selbstfrei'], online: true },
    { id: 'sara', name: 'Sara Mehler', initials: 'SM', role: 'Social Media', workspaces: ['unicornbakery'], online: false },
    { id: 'noah', name: 'Noah Klein', initials: 'NK', role: 'Produktion', workspaces: ['unicornbakery', 'selbstfrei'], online: true },
    { id: 'ines', name: 'Ines Roth', initials: 'IR', role: 'Freelance Cutter', workspaces: ['unicornbakery'], online: false },
    { id: 'kai',  name: 'Kai Sommer', initials: 'KS', role: 'Freelance Editor', workspaces: ['selbstfrei'], online: true },
  ],

  // Episode phases per brand
  phases: {
    unicornbakery: ['Booking', 'Briefing', 'Recording', 'Edit', 'Review', 'Publish'],
    selbstfrei:   ['Research', 'Story', 'Recording', 'Edit', 'Clips', 'Publish'],
  },

  projects: [
    // ===== UnicornBakery =====
    {
      id: 'ub-ep142', workspace: 'unicornbakery',
      name: 'Ep. 142 — Verena Pausder',
      type: 'Episode',
      desc: 'Founder-Politik & Bildungswandel. Geplant als 60-Min-Episode mit drei LinkedIn-Cuts und Newsletter-Recap.',
      status: 'In Progress', priority: 'High',
      progress: 62, phaseIdx: 3,
      due: '2026-05-18',
      owner: 'tim', team: ['tim', 'mara', 'lena', 'sara'],
      slackChannel: '#ub-ep142-pausder', slackConnected: true,
      links: [
        { label: 'Riverside Recording', url: '#' },
        { label: 'Gast-Briefing Notion', url: '#' },
        { label: 'Cover-Concepts Figma', url: '#' },
      ],
    },
    {
      id: 'ub-ep143', workspace: 'unicornbakery',
      name: 'Ep. 143 — Roman Kirsch (Lesara Founder)',
      type: 'Episode',
      desc: 'Retrospektive auf Lesara, Lessons aus dem Scaling und Reflexion nach 8 Jahren.',
      status: 'In Progress', priority: 'High',
      progress: 28, phaseIdx: 1,
      due: '2026-05-25',
      owner: 'tim', team: ['tim', 'noah', 'lena'],
      slackChannel: '#ub-ep143-kirsch', slackConnected: true,
    },
    {
      id: 'ub-ep144', workspace: 'unicornbakery',
      name: 'Ep. 144 — Frank Thelen',
      type: 'Episode',
      desc: 'AI in Europa, Deeptech-Investments, politische Rahmenbedingungen.',
      status: 'Planning', priority: 'Medium',
      progress: 10, phaseIdx: 0,
      due: '2026-06-02',
      owner: 'fabian', team: ['fabian', 'tim'],
      slackChannel: '#ub-ep144-thelen', slackConnected: false,
    },
    {
      id: 'ub-newsletter', workspace: 'unicornbakery',
      name: 'Newsletter Mai · Vol. 21',
      type: 'Newsletter',
      desc: 'Founder-Spotlight, drei Reads, Best of Episodes.',
      status: 'Review', priority: 'Medium',
      progress: 80, phaseIdx: 4,
      due: '2026-05-14',
      owner: 'tim', team: ['tim', 'sara'],
      slackChannel: '#ub-newsletter', slackConnected: true,
    },
    {
      id: 'ub-rebrand', workspace: 'unicornbakery',
      name: 'Cover Refresh Q2',
      type: 'Design',
      desc: 'Neue Cover-Vorlagen für alle Episoden, abgestimmt auf Spotify & Apple.',
      status: 'Blocked', priority: 'Low',
      progress: 35, phaseIdx: 2,
      due: '2026-06-15',
      owner: 'lena', team: ['lena', 'fabian'],
      slackChannel: '#ub-design-q2', slackConnected: true,
      blockedReason: 'Wartet auf Approval Cover-Direction',
    },

    // ===== SelbstFrei =====
    {
      id: 'sf-ep048', workspace: 'selbstfrei',
      name: 'Ep. 048 — Verena Hubertz',
      type: 'Episode',
      desc: 'Politik trifft Gründertum. Hochfrequenter Clip-Cut für TikTok geplant.',
      status: 'In Progress', priority: 'High',
      progress: 75, phaseIdx: 4,
      due: '2026-05-13',
      owner: 'fabian', team: ['fabian', 'jonas', 'paul', 'lena'],
      slackChannel: '#sf-ep048-hubertz', slackConnected: true,
    },
    {
      id: 'sf-ep049', workspace: 'selbstfrei',
      name: 'Ep. 049 — Carsten Maschmeyer',
      type: 'Episode',
      desc: 'Legendäres Founder-Interview. Special-Edition mit 90 Min Laufzeit.',
      status: 'In Progress', priority: 'High',
      progress: 45, phaseIdx: 2,
      due: '2026-05-20',
      owner: 'tim', team: ['tim', 'kai', 'paul'],
      slackChannel: '#sf-ep049-maschmeyer', slackConnected: true,
    },
    {
      id: 'sf-ep050', workspace: 'selbstfrei',
      name: 'Ep. 050 — Jubiläum Special',
      type: 'Episode',
      desc: '50. Episode. Live-Aufnahme mit Publikum geplant. Crossover mit UB-Format.',
      status: 'Planning', priority: 'High',
      progress: 15, phaseIdx: 0,
      due: '2026-06-10',
      owner: 'fabian', team: ['fabian', 'tim', 'lena', 'noah'],
      slackChannel: '#sf-ep050-jubilaeum', slackConnected: false,
    },
    {
      id: 'sf-clips-batch', workspace: 'selbstfrei',
      name: 'Viral Clip Batch · KW20',
      type: 'Clips',
      desc: '12 Shortform-Cuts aus den letzten 4 Episoden für TikTok, Reels, Shorts.',
      status: 'Review', priority: 'High',
      progress: 70, phaseIdx: 4,
      due: '2026-05-12',
      owner: 'paul', team: ['paul', 'kai'],
      slackChannel: '#sf-clips', slackConnected: true,
    },
    {
      id: 'sf-thumbnails', workspace: 'selbstfrei',
      name: 'YouTube Thumbnails Q2',
      type: 'Design',
      desc: 'Neues Thumbnail-System für YouTube — A/B-Testing-Ready.',
      status: 'Blocked', priority: 'Medium',
      progress: 40, phaseIdx: 2,
      due: '2026-06-01',
      owner: 'lena', team: ['lena', 'paul'],
      slackChannel: '#sf-yt-thumbs', slackConnected: true,
      blockedReason: 'Performance-Daten Q1 fehlen noch',
    },
  ],

  tasks: [
    // ===== UnicornBakery =====
    // Pausder
    { id: 't-001', workspace: 'unicornbakery', projectId: 'ub-ep142', title: 'Rough Cut Ep. 142 fertigstellen', assignee: 'mara', status: 'In Progress', priority: 'High', due: '2026-05-11', tags: ['edit'] },
    { id: 't-002', workspace: 'unicornbakery', projectId: 'ub-ep142', title: 'LinkedIn-Header Variante A + B', assignee: 'lena', status: 'In Progress', priority: 'Medium', due: '2026-05-12', tags: ['design', 'linkedin'] },
    { id: 't-003', workspace: 'unicornbakery', projectId: 'ub-ep142', title: 'Episode-Beschreibung schreiben', assignee: 'tim', status: 'To Do', priority: 'Medium', due: '2026-05-14' },
    { id: 't-004', workspace: 'unicornbakery', projectId: 'ub-ep142', title: 'Fabian Review Rough Cut', assignee: 'fabian', status: 'Review', priority: 'High', due: '2026-05-13', tags: ['review'], waitingOn: 'mara' },
    { id: 't-005', workspace: 'unicornbakery', projectId: 'ub-ep142', title: 'Quote-Cards für Instagram', assignee: 'sara', status: 'To Do', priority: 'Low', due: '2026-05-15' },
    { id: 't-006', workspace: 'unicornbakery', projectId: 'ub-ep142', title: 'Spotify Upload vorbereiten', assignee: 'noah', status: 'Backlog', priority: 'Medium', due: '2026-05-17' },

    // Kirsch
    { id: 't-010', workspace: 'unicornbakery', projectId: 'ub-ep143', title: 'Briefing-Doc finalisieren', assignee: 'tim', status: 'In Progress', priority: 'High', due: '2026-05-15' },
    { id: 't-011', workspace: 'unicornbakery', projectId: 'ub-ep143', title: 'Rechercheblock Lesara Story', assignee: 'tim', status: 'To Do', priority: 'Medium', due: '2026-05-17' },
    { id: 't-012', workspace: 'unicornbakery', projectId: 'ub-ep143', title: 'Studio buchen', assignee: 'noah', status: 'Done', priority: 'High', due: '2026-05-10' },

    // Thelen
    { id: 't-020', workspace: 'unicornbakery', projectId: 'ub-ep144', title: 'Termin mit Thelen-Office abstimmen', assignee: 'fabian', status: 'In Progress', priority: 'High', due: '2026-05-13' },
    { id: 't-021', workspace: 'unicornbakery', projectId: 'ub-ep144', title: 'Themen-Pitch aufsetzen', assignee: 'tim', status: 'Backlog', priority: 'Medium', due: '2026-05-18' },

    // Newsletter
    { id: 't-030', workspace: 'unicornbakery', projectId: 'ub-newsletter', title: 'Founder-Spotlight final freigeben', assignee: 'fabian', status: 'Review', priority: 'High', due: '2026-05-12' },
    { id: 't-031', workspace: 'unicornbakery', projectId: 'ub-newsletter', title: 'Mailchimp Vorschau testen', assignee: 'sara', status: 'To Do', priority: 'Medium', due: '2026-05-13' },

    // Rebrand
    { id: 't-040', workspace: 'unicornbakery', projectId: 'ub-rebrand', title: 'Cover-Direction Approval', assignee: 'fabian', status: 'Blocked', priority: 'High', due: '2026-05-11', blocker: 'Warten auf Feedback Fabian seit 3 Tagen' },
    { id: 't-041', workspace: 'unicornbakery', projectId: 'ub-rebrand', title: 'Spotify Asset Spec sammeln', assignee: 'lena', status: 'To Do', priority: 'Low', due: '2026-05-20' },

    // ===== SelbstFrei =====
    // Hubertz
    { id: 't-100', workspace: 'selbstfrei', projectId: 'sf-ep048', title: 'Final Cut Ep. 048 abnehmen', assignee: 'fabian', status: 'Review', priority: 'High', due: '2026-05-11', waitingOn: 'jonas' },
    { id: 't-101', workspace: 'selbstfrei', projectId: 'sf-ep048', title: 'TikTok-Cuts (5×)', assignee: 'paul', status: 'In Progress', priority: 'High', due: '2026-05-12', tags: ['clips', 'tiktok'] },
    { id: 't-102', workspace: 'selbstfrei', projectId: 'sf-ep048', title: 'Thumbnail Hubertz', assignee: 'lena', status: 'In Progress', priority: 'High', due: '2026-05-12', tags: ['design'] },
    { id: 't-103', workspace: 'selbstfrei', projectId: 'sf-ep048', title: 'Posting-Plan KW20 zusammenstellen', assignee: 'paul', status: 'To Do', priority: 'Medium', due: '2026-05-13' },

    // Maschmeyer
    { id: 't-110', workspace: 'selbstfrei', projectId: 'sf-ep049', title: 'Rohmaterial sichern (Backup)', assignee: 'noah', status: 'Done', priority: 'High', due: '2026-05-08' },
    { id: 't-111', workspace: 'selbstfrei', projectId: 'sf-ep049', title: 'Story-Angles brainstormen', assignee: 'tim', status: 'In Progress', priority: 'High', due: '2026-05-13' },
    { id: 't-112', workspace: 'selbstfrei', projectId: 'sf-ep049', title: 'Rough Edit Episode', assignee: 'kai', status: 'In Progress', priority: 'High', due: '2026-05-16' },
    { id: 't-113', workspace: 'selbstfrei', projectId: 'sf-ep049', title: 'Hook-Varianten testen', assignee: 'paul', status: 'To Do', priority: 'Medium', due: '2026-05-17' },

    // Jubiläum
    { id: 't-120', workspace: 'selbstfrei', projectId: 'sf-ep050', title: 'Location Hamburg recherchieren', assignee: 'noah', status: 'In Progress', priority: 'High', due: '2026-05-15' },
    { id: 't-121', workspace: 'selbstfrei', projectId: 'sf-ep050', title: 'Gästeliste finalisieren', assignee: 'fabian', status: 'To Do', priority: 'High', due: '2026-05-18' },
    { id: 't-122', workspace: 'selbstfrei', projectId: 'sf-ep050', title: 'Crossover-Briefing UB', assignee: 'tim', status: 'Backlog', priority: 'Medium', due: '2026-05-25' },

    // Clip Batch
    { id: 't-130', workspace: 'selbstfrei', projectId: 'sf-clips-batch', title: 'Clip-Set #1 (Ep. 046)', assignee: 'paul', status: 'Done', priority: 'Medium', due: '2026-05-09' },
    { id: 't-131', workspace: 'selbstfrei', projectId: 'sf-clips-batch', title: 'Clip-Set #2 (Ep. 047)', assignee: 'kai', status: 'Review', priority: 'High', due: '2026-05-11', waitingOn: 'paul' },
    { id: 't-132', workspace: 'selbstfrei', projectId: 'sf-clips-batch', title: 'Captions-Pass alle Clips', assignee: 'paul', status: 'In Progress', priority: 'Medium', due: '2026-05-12' },

    // Thumbs
    { id: 't-140', workspace: 'selbstfrei', projectId: 'sf-thumbnails', title: 'Performance-Daten Q1 sammeln', assignee: 'fabian', status: 'Blocked', priority: 'High', due: '2026-05-10', blocker: 'YouTube Analytics-Zugang fehlt' },
    { id: 't-141', workspace: 'selbstfrei', projectId: 'sf-thumbnails', title: 'Thumbnail-Variantenset entwerfen', assignee: 'lena', status: 'To Do', priority: 'Medium', due: '2026-05-20' },
  ],

  activity: [
    { id: 'a-001', workspace: 'unicornbakery', user: 'mara', verb: 'pushed Status', target: 't-001', meta: '→ In Progress', time: '2026-05-11T09:42:00', icon: 'arrow-right' },
    { id: 'a-002', workspace: 'unicornbakery', user: 'tim', verb: 'commented on', target: 'ub-ep142', meta: '"Bitte den ersten Teil 20s straffen."', time: '2026-05-11T09:28:00', icon: 'message' },
    { id: 'a-003', workspace: 'unicornbakery', user: 'lena', verb: 'attached File to', target: 'ub-ep142', meta: 'Header-A.fig', time: '2026-05-11T08:55:00', icon: 'paperclip' },
    { id: 'a-004', workspace: 'unicornbakery', user: 'fabian', verb: 'blocked', target: 't-040', meta: 'Approval steht aus', time: '2026-05-11T08:12:00', icon: 'block' },
    { id: 'a-005', workspace: 'unicornbakery', user: 'noah', verb: 'completed', target: 't-012', meta: 'Studio gebucht', time: '2026-05-10T17:33:00', icon: 'check' },
    { id: 'a-006', workspace: 'unicornbakery', user: 'tim', verb: 'assigned', target: 't-003', meta: 'sich selbst', time: '2026-05-10T16:04:00', icon: 'user' },
    { id: 'a-007', workspace: 'unicornbakery', user: 'sara', verb: 'created Task', target: 't-005', meta: 'Quote-Cards', time: '2026-05-10T15:20:00', icon: 'plus' },
    { id: 'a-008', workspace: 'unicornbakery', user: 'tim', verb: 'sent to Slack', target: 't-001', meta: '#ub-ep142-pausder', time: '2026-05-10T11:00:00', icon: 'slack' },

    { id: 'a-101', workspace: 'selbstfrei', user: 'jonas', verb: 'pushed Status', target: 't-100', meta: '→ Review', time: '2026-05-11T10:15:00', icon: 'arrow-right' },
    { id: 'a-102', workspace: 'selbstfrei', user: 'paul', verb: 'commented on', target: 'sf-ep048', meta: '"Hook #3 performt am besten in Tests."', time: '2026-05-11T09:50:00', icon: 'message' },
    { id: 'a-103', workspace: 'selbstfrei', user: 'fabian', verb: 'changed Deadline of', target: 'sf-ep050', meta: '→ 10. Juni', time: '2026-05-11T08:40:00', icon: 'calendar' },
    { id: 'a-104', workspace: 'selbstfrei', user: 'kai', verb: 'requested Feedback on', target: 't-131', meta: 'von Paul', time: '2026-05-11T08:01:00', icon: 'message' },
    { id: 'a-105', workspace: 'selbstfrei', user: 'lena', verb: 'completed', target: 't-110', meta: 'Backup gesichert', time: '2026-05-10T19:22:00', icon: 'check' },
    { id: 'a-106', workspace: 'selbstfrei', user: 'tim', verb: 'sent to Slack', target: 't-111', meta: '#sf-ep049-maschmeyer', time: '2026-05-10T14:15:00', icon: 'slack' },
    { id: 'a-107', workspace: 'selbstfrei', user: 'paul', verb: 'created Task', target: 't-103', meta: 'Posting-Plan KW20', time: '2026-05-10T11:30:00', icon: 'plus' },
  ],

  templates: {
    unicornbakery: {
      name: 'UnicornBakery · Episode Template',
      desc: 'Standardablauf für eine Founder-Episode. 11 Tasks, ø 14 Tage Durchlauf.',
      avgDuration: '14 Tage',
      tasks: [
        { phase: 'Booking', title: 'Gast/Unternehmen bestätigen', owner: 'Manager', daysFromStart: 0 },
        { phase: 'Briefing', title: 'Podcast-Briefing vorbereiten', owner: 'Manager', daysFromStart: 2 },
        { phase: 'Booking', title: 'Aufnahme planen (Studio + Slot)', owner: 'Produktion', daysFromStart: 3 },
        { phase: 'Recording', title: 'Rohmaterial sichern', owner: 'Produktion', daysFromStart: 7 },
        { phase: 'Edit', title: 'Main Episode schneiden', owner: 'Cutter', daysFromStart: 9 },
        { phase: 'Edit', title: 'Shortform Clips erstellen (3×)', owner: 'Cutter', daysFromStart: 10 },
        { phase: 'Edit', title: 'LinkedIn Assets vorbereiten', owner: 'Designer', daysFromStart: 10 },
        { phase: 'Review', title: 'Feedback einholen (Owner)', owner: 'Owner', daysFromStart: 11 },
        { phase: 'Publish', title: 'Upload vorbereiten', owner: 'Produktion', daysFromStart: 13 },
        { phase: 'Publish', title: 'Episode veröffentlichen', owner: 'Produktion', daysFromStart: 14 },
        { phase: 'Publish', title: 'Projektdateien archivieren', owner: 'Cutter', daysFromStart: 14 },
      ],
    },
    selbstfrei: {
      name: 'SelbstFrei · Episode Template',
      desc: 'Story-getriebenes Episodenformat mit starkem Clip-Output.',
      avgDuration: '17 Tage',
      tasks: [
        { phase: 'Research', title: 'Gast recherchieren', owner: 'Manager', daysFromStart: 0 },
        { phase: 'Research', title: 'Gründerstory analysieren', owner: 'Manager', daysFromStart: 1 },
        { phase: 'Story', title: 'Starke Story-Angles finden', owner: 'Manager', daysFromStart: 2 },
        { phase: 'Story', title: 'Virale Hook-Ideen erstellen', owner: 'Social Media', daysFromStart: 3 },
        { phase: 'Story', title: 'Interviewstruktur vorbereiten', owner: 'Manager', daysFromStart: 4 },
        { phase: 'Recording', title: 'Aufnahme planen', owner: 'Produktion', daysFromStart: 5 },
        { phase: 'Recording', title: 'Rohmaterial sichern', owner: 'Produktion', daysFromStart: 9 },
        { phase: 'Edit', title: 'Main Episode schneiden', owner: 'Cutter', daysFromStart: 11 },
        { phase: 'Clips', title: 'Virale Shortform Clips (8×)', owner: 'Cutter', daysFromStart: 13 },
        { phase: 'Clips', title: 'Thumbnail-Ideen erstellen', owner: 'Designer', daysFromStart: 14 },
        { phase: 'Clips', title: 'Titelvarianten erstellen', owner: 'Social Media', daysFromStart: 14 },
        { phase: 'Publish', title: 'Postingplan vorbereiten', owner: 'Social Media', daysFromStart: 15 },
        { phase: 'Publish', title: 'Community aktivieren', owner: 'Social Media', daysFromStart: 16 },
        { phase: 'Publish', title: 'Performance auswerten', owner: 'Manager', daysFromStart: 17 },
      ],
    },
  },

  calendarEvents: {
    unicornbakery: [
      { date: '2026-05-11', type: 'deadline',   title: 'Rough Cut Ep. 142',          projectId: 'ub-ep142' },
      { date: '2026-05-12', type: 'deadline',   title: 'LinkedIn Header A/B',         projectId: 'ub-ep142' },
      { date: '2026-05-13', type: 'review',     title: 'Review Rough Cut',            projectId: 'ub-ep142' },
      { date: '2026-05-13', type: 'recording',  title: 'Recording Ep. 143 Kirsch',    projectId: 'ub-ep143' },
      { date: '2026-05-14', type: 'publish',    title: 'Newsletter Vol. 21',          projectId: 'ub-newsletter' },
      { date: '2026-05-15', type: 'deadline',   title: 'Briefing-Doc Kirsch',         projectId: 'ub-ep143' },
      { date: '2026-05-18', type: 'publish',    title: 'Ep. 142 Veröffentlichung',    projectId: 'ub-ep142' },
      { date: '2026-05-20', type: 'recording',  title: 'Recording Thelen',            projectId: 'ub-ep144' },
      { date: '2026-05-25', type: 'publish',    title: 'Ep. 143 Veröffentlichung',    projectId: 'ub-ep143' },
    ],
    selbstfrei: [
      { date: '2026-05-11', type: 'review',     title: 'Final Cut Hubertz',           projectId: 'sf-ep048' },
      { date: '2026-05-12', type: 'deadline',   title: 'TikTok-Cuts 5×',              projectId: 'sf-ep048' },
      { date: '2026-05-12', type: 'deadline',   title: 'Clip-Batch KW20',             projectId: 'sf-clips-batch' },
      { date: '2026-05-13', type: 'publish',    title: 'Ep. 048 Hubertz Launch',      projectId: 'sf-ep048' },
      { date: '2026-05-15', type: 'recording',  title: 'Recording Maschmeyer',        projectId: 'sf-ep049' },
      { date: '2026-05-16', type: 'deadline',   title: 'Rough Edit Maschmeyer',       projectId: 'sf-ep049' },
      { date: '2026-05-20', type: 'publish',    title: 'Ep. 049 Maschmeyer Launch',   projectId: 'sf-ep049' },
      { date: '2026-05-22', type: 'recording',  title: 'Live Recording Hamburg',      projectId: 'sf-ep050' },
      { date: '2026-06-10', type: 'publish',    title: 'Ep. 050 Jubiläum Launch',     projectId: 'sf-ep050' },
    ],
  },

  slackNotifications: [
    { workspace: 'unicornbakery', channel: '#ub-ep142-pausder', user: 'Tim', text: '@Mara Rough-Cut bitte bis morgen 10 Uhr.', time: 'vor 14 Min' },
    { workspace: 'unicornbakery', channel: '#ub-newsletter',    user: 'Sara', text: 'Mailchimp Vorschau ist raus — Test in eurer Inbox.', time: 'vor 41 Min' },
    { workspace: 'selbstfrei',    channel: '#sf-ep048-hubertz', user: 'Paul', text: 'Hook #3 schlägt #1 in beiden Test-Posts.', time: 'vor 23 Min' },
    { workspace: 'selbstfrei',    channel: '#sf-clips',         user: 'Kai',  text: 'Set #2 hochgeladen — bitte 1× Review.', time: 'vor 1 Std' },
  ],
};
